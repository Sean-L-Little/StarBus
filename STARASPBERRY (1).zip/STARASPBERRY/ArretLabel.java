import java.awt.Color;
import javax.swing.*;
import java.awt.Font;
import java.io.IOException;
import java.io.File;
import java.io.FileInputStream;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ArretLabel extends JLabel   {



    public  ArretLabel(String s){
        super(s);
        try{
        Font f = Font.createFont(Font.TRUETYPE_FONT,new FileInputStream(new File("Stem Text W03 Bold.ttf"))).deriveFont(Font.PLAIN, 20);
        this.setFont(f);
      }
      catch(Exception e){

          e.printStackTrace();
      }
        this.setForeground(Color.BLACK);






    }















}
