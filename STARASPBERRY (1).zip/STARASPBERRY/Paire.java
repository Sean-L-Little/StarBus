import javax.swing.*;



public class Paire {

  private LabelHoraires fst;
  private LabelHoraires snd;

  public Paire(LabelHoraires fst, LabelHoraires snd){

    this.fst=fst;
    this.snd=snd;




  }

  public void setFst(LabelHoraires jl){

    this.fst=jl;


  }

  public void setSnd(LabelHoraires jl){

    this.snd=jl;

  }

  public LabelHoraires getFst(){
    return this.fst;

  }

  public LabelHoraires getSnd(){

    return this.snd;

  }





}
