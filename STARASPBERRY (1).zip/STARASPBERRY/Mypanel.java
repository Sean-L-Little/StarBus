import javax.swing.*;
import java.awt.*;
import java.util.Random;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;




public class Mypanel extends JPanel implements ActionListener{

   private Paire[] listeJLabel;

   private Pair[] charToReplace= new Pair[16];

   private int oldIndiceRemplissage;






   //protected Dimension arcs = new Dimension(20, 20);







    public ArretBus ab;


    public Mypanel(ArretBus ab ){


      super();  //carefull



      this.setBackground(Color.BLACK);
      this.setOpaque(false);

      this.ab=ab;
      //System.out.println("INdicce rempliii " + ab.getIndiceRemplissage());

      if(ab.getIndiceRemplissage() == -1){

        this.setLayout(new GridLayout(1, 4 ));

      }else {


      this.setLayout(new GridLayout(ab.getIndiceRemplissage()+1, 4 ) );

    }





      this.setBorder(BorderFactory.createEmptyBorder(10, 40, 10, 40));

      charToReplace[0]=new Pair("ë","e");
      charToReplace[1]=new Pair("é","e");
      charToReplace[2]=new Pair("è","e");
      charToReplace[3]=new Pair("ê","e");
      charToReplace[4]=new Pair("à","a");
      charToReplace[5]=new Pair("â","a");
      charToReplace[6]=new Pair("ä","a");
      charToReplace[7]=new Pair("ù","u");
      charToReplace[8]=new Pair("ü","u");
      charToReplace[9]=new Pair("û","u");
      charToReplace[10]=new Pair("ç","c");
      charToReplace[11]=new Pair("ï","i");
      charToReplace[12]=new Pair("î","i");
      charToReplace[13]=new Pair("ö","o");
      charToReplace[14]=new Pair("ô","o");
      charToReplace[15]=new Pair("ÿ","y");






      listeJLabel=new Paire[Main.HORAIRE_PAR_ARRET];







      majListeJLabel();

      //adaptFontSize();





      Timer t = new Timer(30000, this);
      t.start();



    }

    public void majListeJLabel(){



      LabelHoraires lhAttente;
      LabelHoraires lhHeureDepart;

      if(ab.getIndiceRemplissage() == -1){

        this.setLayout(new GridLayout(1, 4));

        this.add(new LabelHoraires( cleanString(ab.getNomLigne()))   );
        this.add(new LabelHoraires( cleanString( ab.getDirection()) ) );
        this.add(new LabelHoraires( cleanString( "SERVICE") ) );
        this.add(new LabelHoraires( cleanString( "TERMINE") ) );

        int oldIndiceRemplissage=ab.getIndiceRemplissage();






      }else{

      this.setLayout(new GridLayout(ab.getIndiceRemplissage()+1, 4)) ;

      for(int i =0; i<= ab.getIndiceRemplissage(); i++){



        this.add(new LabelHoraires( cleanString(ab.getNomLigne()))   );



        this.add(new LabelHoraires( cleanString( ab.getDirection()) ) );


        if(ab.getAttente(i) > 60 ){

          lhAttente=new LabelHoraires( "> 1 HEURE");
          this.add(lhAttente);






        }else{



        lhAttente=new LabelHoraires( Long.toString(  ab.getAttente(i) ));
        lhAttente.setHorizontalAlignment(SwingConstants.CENTER);


        this.add(lhAttente);

      }



        lhHeureDepart=new LabelHoraires( ab.getProchainDepartToString(i) );
        this.add( lhHeureDepart);

        listeJLabel[i]=new Paire(lhAttente, lhHeureDepart);

        }

        int oldIndiceRemplissage=ab.getIndiceRemplissage();



      }





      }


      public void adaptFontSize() {
    Component[] component = this.getComponents();

    // Reset user interface
    for(int i=0; i<component.length; i++)  {
        if (component[i] instanceof LabelHoraires)  {
            LabelHoraires label = (LabelHoraires)component[i];
            //button.setEnabled(true);
            System.out.println("TAILLLLLLEE    "+label.getHeight());
        }

    }
}







    public void actionPerformed(ActionEvent ae ){


      this.ab.majListeAttentes();

      if(this.ab.getIndiceRemplissage() != oldIndiceRemplissage ){

        this.removeAll();


        this.majListeJLabel();
        oldIndiceRemplissage=ab.getIndiceRemplissage();






      }else{

        majListeJLabel2();




        //nouvelle fonction où cette fois ci on met a jour avec setText et non removeAll puis readd All !!!



      }




/*
      for(int i =0; i<Main.HORAIRE_PAR_ARRET; i++){

        listeJLabel[i].getFst().setText( Long.toString(  ab.getAttente(i) ) );


        System.out.println(Long.toString( ab.getAttente(i))  );




        listeJLabel[i].getSnd().setText( ab.getProchainDepartToString(i)  );
        System.out.println(listeJLabel[i].getFst().getText());





      } */

        this.revalidate();
        this.repaint();


      }


      public void majListeJLabel2(){






        for(int i =0; i<= oldIndiceRemplissage; i++){

          listeJLabel[i].getFst().setText( Long.toString(  ab.getAttente(i) ));


          //System.out.println(Long.toString( ab.getAttente(i))  );




          listeJLabel[i].getSnd().setText( ab.getProchainDepartToString(i)  );
          //System.out.println(listeJLabel[i].getFst().getText());














      }

    }

      public String cleanString(String s){
        String temp=s;
        for(int i=0; i<16; i++){
          temp=temp.replaceAll(charToReplace[i].getKey(), charToReplace[i].getValue());

        }

        return temp;

      }






}
