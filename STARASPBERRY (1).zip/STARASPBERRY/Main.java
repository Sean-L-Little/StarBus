import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.Enumeration;
import javax.swing.SwingUtilities;






public class Main{


final static int MAX_ARRET=3;
final static int HORAIRE_PAR_ARRET=3;
static ArretBus[] listeArretBus=new ArretBus[MAX_ARRET];
static Fenetre2 f;




public static void main (String[] args){


  //ArretBus stCow=new ArretBus("9", "Saint-Laurent", "Saint-Conwoion");
  initListeArretBus();
  //majListeArretBus(1, "9", "Saint-Laurent", "Saint-Conwoion");
  Thread t=new Thread(new Ecoute());
	t.start();
  f=new Fenetre2();



  /*  while(true){

      try{

      //System.out.println(stCow.getAttente());

      System.out.println("LIGNE      DIRECTION                   ATTENTE (min)     HEURE");
      System.out.println();
      majListeArretBus();

      printListeArretBus();
      System.out.println("//////////////////////////////////////////////////////////");



      Thread.sleep(30 * 1000);

    }
    catch(Exception e){e.printStackTrace();}



  } */



}

public static void initListeArretBus(){

  for (int i =0; i<MAX_ARRET; i++){

    listeArretBus[i]=null;


  }


}


public static void updateListeArretBus(int indiceListeArret, String numeroLigne, String direction, String arretBus){

    ArretBus a = new ArretBus(numeroLigne, direction, arretBus);
    listeArretBus[indiceListeArret]=a;
    System.out.println("LIGNE      DIRECTION                   ATTENTE (min)     HEURE");
    printListeArretBus();



}

public static void majListeArretBus(){

  for (int i =0; i< MAX_ARRET; i++){

    if(listeArretBus[i] != null ) {

      listeArretBus[i].majListeAttentes();
    }






    }

}

public static void printListeArretBus(){

  for (int i =0; i<MAX_ARRET; i++){

    if(listeArretBus[i] != null ) {

      //System.out.print("slot "+i+ " | ");
      System.out.println(listeArretBus[i]);
    }


}

}

public static void supprimerArret(int indice){

    listeArretBus[indice]=null;



}










}
