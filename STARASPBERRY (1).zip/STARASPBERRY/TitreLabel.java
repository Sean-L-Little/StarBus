import java.awt.Color;
import javax.swing.*;
import java.awt.Font;
import java.io.IOException;
import java.io.File;
import java.io.FileInputStream;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.border.Border;

public class TitreLabel extends JLabel   {



    public  TitreLabel(String s){
        super(s);
        try{
        Font f = Font.createFont(Font.TRUETYPE_FONT,new FileInputStream(new File("Stem Text W03 Bold.ttf"))).deriveFont(Font.BOLD, 30);
        this.setFont(f);
      }
      catch(Exception e){

          e.printStackTrace();
      }


      this.setBorder(BorderFactory.createEmptyBorder(0, 30, 3, 0));



        this.setForeground(Color.WHITE);






    }















}
