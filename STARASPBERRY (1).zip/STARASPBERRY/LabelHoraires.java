import java.awt.Color;
import javax.swing.*;
import java.awt.Font;
import java.io.IOException;
import java.io.File;
import java.io.FileInputStream;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.border.Border;
import javax.swing.border.LineBorder;

public class LabelHoraires extends JLabel    {






    public  LabelHoraires(String s){
        super(s);

        Border border = LineBorder.createGrayLineBorder();

      //  this.setBorder(border);

        this.setForeground(Color.BLACK);

      //  this.setBorder(BorderFactory.createEmptyBorder(0, 30, 0, 30));






        try{
          Font labelFont = Font.createFont(Font.TRUETYPE_FONT,new FileInputStream(new File("DS-DIGI.TTF"))).deriveFont(Font.BOLD, 45);

          this.setFont(labelFont);



      }
      catch(Exception e){

          e.printStackTrace();
      }





    }







    }
