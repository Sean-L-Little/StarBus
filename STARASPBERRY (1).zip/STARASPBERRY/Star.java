import java.io.*;
import java.net.*;
import java.util.*;
import javax.net.ssl.HttpsURLConnection;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.SimpleDateFormat;
import org.json.simple.ItemList;
import org.json.simple.JSONArray;
import org.json.simple.JSONAware;
import org.json.simple.JSONObject;
import org.json.simple.JSONStreamAware;
import org.json.simple.JSONValue;
import org.json.simple.parser.ContainerFactory;
import org.json.simple.parser.ContentHandler;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.json.simple.parser.Yytoken;
import java.text.DateFormat;
import java.util.Date;

public class  Star {


    private static String accessKey = "c0a50b783dba345059c2181132ae15f41a914b124510a6b0cc2ec3ab";
    private static String host = "https://data.explore.star.fr";





    public static Date[] getProchainsPassages (String urlString) throws Exception {
        //String text = parser.parse(new FileReader)




        byte[] encoded_text = new byte[1000];

        URL url = new URL(urlString);
        HttpsURLConnection connection = (HttpsURLConnection) url.openConnection();
        connection.setRequestMethod("GET");
        connection.setRequestProperty("Content-Type", "text/json");
        connection.setRequestProperty("Ocp-Apim-Subscription-Key", accessKey);




        StringBuilder response = new StringBuilder ();
        BufferedReader in = new BufferedReader(
        new InputStreamReader(connection.getInputStream()));
        String line;
        while ((line = in.readLine()) != null) {
            response.append(line);
        }
        in.close();

        try{

          //return parserRequete(reponse);


          return parserRequete(response.toString());
      }
      catch(Exception e){e.printStackTrace();
                          return null;}



    }

    public static Date toDate(String heure){

      try{


        String isoDatePattern = "yyyy-MM-dd'T'HH:mm:ssX";

        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(isoDatePattern);


        Date depart=simpleDateFormat.parse(heure);
        return depart;

    }
    catch(Exception e){e.printStackTrace();
        return null;}

  }








    public static String getHost(){

      return host;

    }

     public static Date[] parserRequete(String reponseJson) throws Exception {

      JSONParser parser = new JSONParser();

        try{
          Object obj= parser.parse(reponseJson);
          JSONObject jsonObject = (JSONObject) obj;






          JSONArray records = (JSONArray) jsonObject.get("records");
          //System.out.println(records.toString());
          //JSONObject temp = records.getJsonObject(0);
      //    JSONObject temp= (JSONObject) records.get(0);






    //      JSONObject fields= (JSONObject) temp.get("fields");

        //  String depart = (String) fields.get("depart");




          return  parserRecords(records);


        }
        catch(ParseException e) {e.printStackTrace();
                                  return null;}





    }

    public static Date[] parserRecords(JSONArray records ){

                Date dateActuelle=new Date();
                Date[] prochainsPassages=new Date[Main.HORAIRE_PAR_ARRET];
                boolean trouve= false;

                @SuppressWarnings("unchecked")


                Iterator<JSONObject> iterator = records.iterator();

                while (iterator.hasNext() && !trouve ) {

                    JSONObject j= iterator.next();
                    JSONObject fields= (JSONObject) j.get("fields");
                    String departString = (String) fields.get("depart");
                    Date departDate= toDate(departString);

                    if(departDate.after(dateActuelle)){
                      trouve=true;
                      System.out.println("TROUVE");




                      int i=0;

                      prochainsPassages[i]=departDate;
                      i++;



                      while (iterator.hasNext() && i < Main.HORAIRE_PAR_ARRET){
                          // System.out.println(getProchainDepartToString(prochainsPassages, i));
                           j=iterator.next();
                           fields= (JSONObject) j.get("fields");
                           departString = (String) fields.get("depart");
                           departDate= toDate(departString);
                           prochainsPassages[i]=departDate;
                           i++;


                        }





                    }






                }

                return prochainsPassages;







    }

    public static String getProchainDepartToString(Date[] d, int indice){


      DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
      String res=dateFormat.format(d[indice]);
      return res;




    }

    public static String getAccessKey(){

      return accessKey;



    }

  /*  public static void main (String[] args) {

            while(true){

            try {
              String response = GetHoraire();
              String[] cut= response.split("T");
              String[] split = cut[1].split("\\+");


//Date date1=new SimpleDateFormat("dd/MM/yyyy").parse(sDate1);
//System.out.println(sDate1+"\t"+date1);
              System.out.println(split[0]);

            Thread.sleep(60 * 1000);

          }
         catch(Exception e){e.printStackTrace();}


          }

        }//fin MAIN   */


    }
