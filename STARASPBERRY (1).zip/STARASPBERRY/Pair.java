


public class Pair {

  private String key;
  private String value;

  public Pair(String fst, String snd){

    this.key=fst;
    this.value=snd;




  }



  public String getKey(){
    return this.key;

  }

  public String getValue(){

    return this.value;

  }





}
