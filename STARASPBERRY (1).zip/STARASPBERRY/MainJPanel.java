import javax.swing.*;
import java.awt.*;
import java.util.Random;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;



class MainJPanel extends JPanel   {


    JPanel titrePanel;

    Mymainpanel horairesPanel;




    public MainJPanel()   {


        super(new BorderLayout());
        titrePanel=new JPanel(new GridLayout(1, 4 ));

        titrePanel.setBackground(new Color(17, 86, 164));



        titrePanel.add(new TitreLabel("Ligne"));
        titrePanel.add(new TitreLabel("Direction"));
        titrePanel.add(new TitreLabel("Attente (min)"));
        titrePanel.add(new TitreLabel("Heure"));
        titrePanel.setBorder(BorderFactory.createEmptyBorder(5, 30, 5, 30));





        //horairesPanel= new HorairesPanel();
        horairesPanel=new Mymainpanel();



        this.add(titrePanel, BorderLayout.PAGE_START);
        this.add(horairesPanel, BorderLayout.CENTER);




        /*contentPane = new JPanel(new GridLayout(2,1));
        pinkPanel = new JPanel();
        pinkPanel.setBackground(Color.PINK);

        yellowPanel = new JPanel();
        yellowPanel.setBackground(Color.YELLOW);

        bluePanel = new JPanel();
        bluePanel.setBackground(Color.BLUE);

        twoPanelContainer = new JPanel(new GridLayout(1,2));
        twoPanelContainer.add(yellowPanel);
        twoPanelContainer.add(bluePanel);

        contentPane.add(pinkPanel);
        contentPane.add(twoPanelContainer);

        frame.setContentPane(contentPane);

*/


    }














}
