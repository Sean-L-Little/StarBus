import javax.swing.*;
import java.awt.*;
import java.util.Random;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;




public class Mymainpanel extends JPanel implements ActionListener{

  //private Mypanel[] mp= new Mypanel[Main.MAX_ARRET];

  public PanelArret[] mp= new PanelArret[Main.MAX_ARRET];



    public Mymainpanel(){

      super(new GridLayout(0, 1, 0, 15) );

      //this.setBackground(new Color(13, 133, 157));
      this.setBackground(new Color(17, 86, 164));


      this.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));


      initMp();



      Timer t = new Timer(1000, this);
      t.start();



    }

    public void initMp(){


      for(int i =0; i<Main.MAX_ARRET; i++){

        mp[i]=null;




      }
    }

    public void setMp(PanelArret p, int i){
      this.mp[i]=p;




    }
    public void supMp(int i){


      mp[i]=null;

    }






    public void actionPerformed(ActionEvent ae ){

      this.removeAll();


      int minFont=Integer.MAX_VALUE;



      for(int i =0; i<Main.MAX_ARRET; i++){

        if(mp[i] != null){



          this.add(mp[i]);
          Component[] tab=mp[i].p.getComponents();

          int minFontSizeToUse=fontSizeToUse((LabelHoraires)tab[0]);


          for(int j=1; j<tab.length; j++){

            if(tab[j] instanceof LabelHoraires){





              LabelHoraires lh=(LabelHoraires)tab[j];
              if (fontSizeToUse(lh) < minFontSizeToUse){


                minFontSizeToUse=fontSizeToUse(lh);



              }


            }




          }

          if(minFontSizeToUse < minFont){

            minFont=minFontSizeToUse;

          }



        }


      }


      for(int x =0; x<Main.MAX_ARRET; x++){

        if(mp[x] != null){


          Component[] temp=mp[x].p.getComponents();

          for(int i=0; i<temp.length; i++){


            if(temp[i] instanceof LabelHoraires){

              LabelHoraires lh=(LabelHoraires)temp[i];

              lh.setForeground(new Color(247,184,22));
              lh.setFont(new Font(lh.getFont().getName(), Font.BOLD, minFont));



            }



          }




        }


      }





      this.revalidate();
      this.repaint();






    }

    public static int fontSizeToUse(LabelHoraires lh){

      int stringWidth = lh.getFontMetrics(lh.getFont()).stringWidth(lh.getText());

      //System.out.println("stringWidth   "+ stringWidth);

      int componentWidth = lh.getWidth();

      //  System.out.println("componentWidth   "+ componentWidth);


      // Find out how much the font can grow in width.
      double widthRatio = (double)componentWidth / (double)stringWidth;

      int newFontSize = (int)(lh.getFont().getSize() * widthRatio);
      int componentHeight = lh.getHeight();

      // Pick a new font size so it will not be larger than the height of label.
      int fontSizeToUse = Math.min(newFontSize, componentHeight)-10;


      return fontSizeToUse;

    //  this.setFont(new Font(labelFont.getName(), Font.PLAIN, fontSizeToUse));
      //this.labelFont=temp;
    //  this.labelText=this.getText();








    }






}
