import java.io.BufferedReader;
import java.io.IOException;
import java.awt.List;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;


public class Ecoute implements Runnable {


	final static int PORT_ECOUTE = 4444;




	@Override
	public void run() {

		try {
			ServerSocket socketServeur = new ServerSocket(PORT_ECOUTE);
			try {
				while (true) {
					//System.out.println("attends les clients");
					Socket socketVersUnClient = socketServeur.accept();
					System.out.println("Le client" + socketVersUnClient.getInetAddress() + " est connecté");
					traiterSocketCliente(socketVersUnClient);

				}
			} catch (IOException exception) {
				System.out.println("Erreur " + exception.getMessage());
			} finally {
				socketServeur.close();
			}

		} catch (IOException e) {
			e.printStackTrace();
		}

		// Traitement des exceptions

		// Dans une boucle, pour chaque socket clientes, appeler traiterSocketCliente

	}

  public static void traiterSocketCliente(Socket socketVersUnClient) {
		// Créer printer et reader

		try {
			BufferedReader in = creerReader(socketVersUnClient);
			String currentLine;
			while ((currentLine = recevoirMessage(in)) != null) {
			System.out.println("message reçu : "+currentLine);
      majRaspberry(currentLine);


			}
			System.out.println();
			socketVersUnClient.close();

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// Tant quil ya un message à lire via recevoirMessage

		// Envoyer message au client via envoyerMessage

		// Si plus de ligne à lire fermer socket cliente
	}



  public static BufferedReader creerReader(Socket socketVersUnClient) throws IOException {
  		// créé un BufferedReader associé à la Socket
  		BufferedReader in = new BufferedReader(new InputStreamReader(socketVersUnClient.getInputStream()));
  		return in;

  	}

    public static void majRaspberry(String currentLine){

        String[] cut = currentLine.split("/");
				if(cut[0].equals("sup")){

					int indiceArretToSup=Integer.parseInt(cut[1]);
					Main.supprimerArret(indiceArretToSup);
					Main.f.mp.horairesPanel.supMp(indiceArretToSup);




				}else {
        int indiceListeArret= Integer.parseInt(cut[0]);
				//System.out.println("YYYYYAAAAAAAAAAAAAAAASs");
        Main.updateListeArretBus(indiceListeArret, cut[1], cut[2], cut[3]);

				ArretBus ab=new ArretBus(cut[1], cut[2], cut[3]);

				Mypanel mp=new Mypanel(ab);

				PanelArret pa=new PanelArret(mp);

				Main.f.mp.horairesPanel.setMp( pa, indiceListeArret);
			}








    }

    public static String recevoirMessage(BufferedReader reader) throws IOException {
		try {
		String currentLine = reader.readLine();
		return currentLine;
		}catch (IOException exception) {
			System.out.println("Erreur " + exception.getMessage());
			return null;
		}

		// Récupérer une ligne
		// Retourner la ligne lue ou null si aucune ligne à lire.
	}










}
