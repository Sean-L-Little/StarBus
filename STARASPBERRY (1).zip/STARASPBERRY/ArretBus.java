import java.io.*;
import java.net.*;
import java.util.*;
import javax.net.ssl.HttpsURLConnection;
import java.text.*;
import java.util.concurrent.TimeUnit;


import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.*;




public class ArretBus {

  // final private static int MAX_HORAIRE_PAR_ARRET=10;

   private String nomLigne;
   private String direction;
   private String nomArret;

   private Date[] listeProchainsPassages;
   private long[] listeAttentes;
   //private Date depart;
   //private Long attente;
   private String url;

  // private Paire[] listeJLabel;
    private int indiceRemplissage;









   public ArretBus(String nomLigne, String direction, String nomArret ){

      this.nomLigne=nomLigne;
      this.direction=direction;
      this.nomArret=nomArret;
      listeProchainsPassages=new Date[Main.HORAIRE_PAR_ARRET];
      listeAttentes=new long[Main.HORAIRE_PAR_ARRET];
      initUrl();
      majListeAttentes();
    //  initListeJLabel();


   }

  /* public void initListeJLabel(){

    listeJLabel=new Paire[Main.HORAIRE_PAR_ARRET];

     for(int i=0; i<Main.HORAIRE_PAR_ARRET; i++){

       listeJLabel[i]=new Paire(new LabelHoraires(Long.toString(listeAttentes[i]) ), new LabelHoraires(getProchainDepartToString(i)) );

     }



   } */










   public long[] getListeAttentes(){


     return this.listeAttentes;
   }

   public long getAttente(int indice){


      return this.listeAttentes[indice];


   }

   public String getNomLigne(){


     return this.nomLigne;
   }

   public String getDirection(){


     return this.direction;
   }

   public String getNomArret(){

     return this.nomArret;


   }

   public int getIndiceRemplissage(){

     return indiceRemplissage;


   }

   public String getUrl(){

     return this.url;
   }

   public String getHeureActuelleToString(){

     Date heureActuelle=new Date();
     DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
     String res=dateFormat.format(heureActuelle);
     return res;


   }


   //indice compris entre 0 et MAX_HORAIRE_PAR_ARRET exclu
   public String getProchainDepartToString(int indice){


     DateFormat dateFormat = new SimpleDateFormat("HH:mm");
     String res=dateFormat.format(this.listeProchainsPassages[indice]);
     return res;



   }






   public Date[] getlisteProchainsPassages(){
     return this.listeProchainsPassages;
   }

   private void initUrl(){

     String host = Star.getHost();

     String nomLigne=this.nomLigne.replaceAll(" ","+");
     String direction=this.direction.replaceAll(" ","+");
     String nomArret=this.nomArret.replaceAll(" ", "+");

     String path = "/api/records/1.0/search/?dataset=tco-bus-circulation-passages-tr&rows=40&sort=-depart&facet=precision&refine.nomcourtligne="+nomLigne+"&refine.destination="+direction+"&timezone=Europe%2FParis&q=nomarret:"+nomArret;
     this.url=host+path+"&apikey="+Star.getAccessKey();
     System.out.println(this.url);


   }







   public void majListeAttentes(){


      majListeProchainsPassages();



      for (int i=0; i<=indiceRemplissage;i++){
          majAttenteUnPassage(i);


      }







   }

   public void majAttenteUnPassage(int indice){


     Date heureActuelle=new Date();




     if(listeProchainsPassages[indice] != null){

     long difference = this.listeProchainsPassages[indice].getTime() - heureActuelle.getTime();
     long diffSeconds = difference / 1000 % 60;
     long diffMinutes = difference / (60 * 1000) % 60;
     long minutes = TimeUnit.MILLISECONDS.toMinutes(difference);

     System.out.println(minutes+"  "+indice);


     if (diffSeconds>30){
       diffMinutes++;
     }

     if (diffMinutes<0){
       diffMinutes=0;
     }
     this.listeAttentes[indice]=minutes;

   }




   }

   private void majListeProchainsPassages(){

     int calculRemplissage=-1;

    try{
    this.listeProchainsPassages= Star.getProchainsPassages(this.url);

    for(int i=0; i<Main.HORAIRE_PAR_ARRET; i++){

      if(listeProchainsPassages[i] != null){
        calculRemplissage++;

      }



    }
    indiceRemplissage=calculRemplissage;

  }catch(Exception e) {e.printStackTrace(); }

  }

  public String toString(){

    String res="";
    String newLine = System.getProperty("line.separator");



    for (int i=0; i<= indiceRemplissage; i++){

      res=res+this.nomLigne+printNtimes(" ", 11-this.nomLigne.length() )+this.direction+printNtimes(" ", 28- this.direction.length() )+this.listeAttentes[i]+printNtimes(" ", 18-String.valueOf(this.listeAttentes[i]).length())+this.getProchainDepartToString(i)+newLine;

     //res="bus "+this.nomLigne+", direction : "+this.direction+" arrive dans : "+this.listeAttente[]+" min à l'arrêt : "+this.nomArret+" à : "+this.getDepartToString();

  }

    res=res+"________________________________________________________________________________";
    return res;



  }

  private static String printNtimes(String toPrint, int n){
      String res ="";

      for (int i=0; i<n; i++){
        res=res+toPrint;



      }
      return res;



  }




   }


     //A ECRIRE
     //puis faire class Main dans autre fichier
     //atente attribut ?
