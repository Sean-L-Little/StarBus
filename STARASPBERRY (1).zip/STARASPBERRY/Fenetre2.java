import java.awt.Color;
import javax.swing.*;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;



public class Fenetre2 extends JFrame {

  public MainJPanel mp;




  public Fenetre2(){
    this.setTitle("Horaire star");
    this.setSize(2500, 1400);
    this.setLocationRelativeTo(null);

    //Instanciation d'un objet JPanel
    //JPanel pan = new JPanel();
    //Définition de sa couleur de fond
  //  pan.setBackground(Color.BLACK);
    //On prévient notre JFrame que notre JPanel sera son content pane
    //this.setContentPane(pan);






    mp= new MainJPanel();





    this.getContentPane().add(mp);






    this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

    //this.setExtendedState(JFrame.MAXIMIZED_BOTH);
    //this.setUndecorated(true);





    this.setVisible(true);

  }







}
